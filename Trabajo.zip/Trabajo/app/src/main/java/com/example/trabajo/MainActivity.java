package com.example.trabajo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    EditText edtcaja1, edtcaja2;
    Button   btnIngresar;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        edtcaja1=findViewById(R.id.edtcaja1);
        edtcaja2=findViewById(R.id.edtcaja2);
        btnIngresar=findViewById(R.id.btnIngresar);

        btnIngresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                entrar();
            }
        });
        
    }

    private void entrar() {
        String caja1 =  edtcaja1.getText().toString();
        String caja2 =  edtcaja2.getText().toString();

        if (caja1.isEmpty() || caja2.isEmpty()) {
            Toast.makeText(MainActivity.this, "Por favor llenar los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        if (caja1.equals("uac123") && caja2.equals("12345678")){
            Toast.makeText(MainActivity.this, "¡Bienvenido!", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(MainActivity.this, Parte2.class);
            startActivity(intent);
        }else{
            Toast.makeText(MainActivity.this, "Usuario o contraseña incorrectos",Toast.LENGTH_LONG).show();
        }
    }
}